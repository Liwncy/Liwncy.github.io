import{r as i,j as c,n as v,a as x,b as o,g as n,w as l,aH as r,aD as d,h as s}from"./index-B-bRT4PR.js";const b={class:"markdown-body"},V={style:{display:"flex","justify-content":"space-between","margin-top":"20px"}},N={},U={__name:"iconPicker",setup(j,{expose:y}){let t=i("layui-icon-home");return t=i("layui-icon-home"),t=i("layui-icon-home"),t=i("layui-icon-home"),t=i("layui-icon-home"),y({frontmatter:{}}),(q,a)=>{const f=c("lay-anchor"),p=c("lay-field"),u=c("lay-icon-picker"),k=c("lay-code"),w=c("lay-table-box"),g=c("lay-icon"),m=c("router-link");return x(),v("div",b,[o(f,{anchors:"基本介绍,基础使用,禁用选择,选择清空,开启分页,开启搜索,icon-picker 属性",currIndex:-1,show:!0}),o(p,{id:"基本介绍",title:"基本介绍",style:{"margin-top":"21px","margin-bottom":"20px"}}),a[18]||(a[18]=n("div",{class:"describe-plugin"},[n("p",null,"内置 icon 图标选择组件, 常用于权限管理, 菜单定制。")],-1)),o(p,{id:"基础使用",title:"基础使用",style:{"margin-top":"21px","margin-bottom":"20px"}}),o(k,null,{description:l(()=>[...a[5]||(a[5]=[n("p",null,"使用 lay-icon-picker 标签, 创建图标选择器",-1)])]),code:l(()=>[...a[6]||(a[6]=[n("pre",null,[n("code",{"v-pre":""},[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("lay-icon-picker")]),s(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("icon"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("lay-icon-picker")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[s(`
`),n("span",{class:"token keyword"},"import"),s(),n("span",{class:"token punctuation"},"{"),s(" ref "),n("span",{class:"token punctuation"},"}"),s(),n("span",{class:"token keyword"},"from"),s(),n("span",{class:"token string"},"'vue'"),s(`

`),n("span",{class:"token keyword"},"export"),s(),n("span",{class:"token keyword"},"default"),s(),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`

    `),n("span",{class:"token keyword"},"const"),s(" icon "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},'"layui-icon-home"'),n("span",{class:"token punctuation"},")"),s(`

    `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token punctuation"},"{"),s(`
      icon
    `),n("span",{class:"token punctuation"},"}"),s(`
  `),n("span",{class:"token punctuation"},"}"),s(`
`),n("span",{class:"token punctuation"},"}"),s(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("script")]),n("span",{class:"token punctuation"},">")]),s(`
`)])],-1)])]),default:l(()=>[o(u,{modelValue:d(t),"onUpdate:modelValue":a[0]||(a[0]=e=>r(t)?t.value=e:t=e)},null,8,["modelValue"])]),_:1}),o(p,{id:"禁用选择",title:"禁用选择",style:{"margin-top":"21px","margin-bottom":"20px"}}),o(k,null,{description:l(()=>[...a[7]||(a[7]=[n("p",null,"使用 lay-icon-picker 标签, 创建图标选择器",-1)])]),code:l(()=>[...a[8]||(a[8]=[n("pre",null,[n("code",{"v-pre":""},[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("lay-icon-picker")]),s(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("icon"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},":disabled"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("true"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("lay-icon-picker")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[s(`
`),n("span",{class:"token keyword"},"import"),s(),n("span",{class:"token punctuation"},"{"),s(" ref "),n("span",{class:"token punctuation"},"}"),s(),n("span",{class:"token keyword"},"from"),s(),n("span",{class:"token string"},"'vue'"),s(`

`),n("span",{class:"token keyword"},"export"),s(),n("span",{class:"token keyword"},"default"),s(),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`

    `),n("span",{class:"token keyword"},"const"),s(" icon "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},'"layui-icon-home"'),n("span",{class:"token punctuation"},")"),s(`

    `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token punctuation"},"{"),s(`
      icon
    `),n("span",{class:"token punctuation"},"}"),s(`
  `),n("span",{class:"token punctuation"},"}"),s(`
`),n("span",{class:"token punctuation"},"}"),s(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("script")]),n("span",{class:"token punctuation"},">")]),s(`
`)])],-1)])]),default:l(()=>[o(u,{modelValue:d(t),"onUpdate:modelValue":a[1]||(a[1]=e=>r(t)?t.value=e:t=e),disabled:!0},null,8,["modelValue"])]),_:1}),o(p,{id:"选择清空",title:"选择清空",style:{"margin-top":"21px","margin-bottom":"20px"}}),o(k,null,{description:l(()=>[...a[9]||(a[9]=[n("p",null,"使用 lay-icon-picker 标签, 创建图标选择器",-1)])]),code:l(()=>[...a[10]||(a[10]=[n("pre",null,[n("code",{"v-pre":""},[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("lay-icon-picker")]),s(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("icon"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},":allow-clear"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("true"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("lay-icon-picker")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[s(`
`),n("span",{class:"token keyword"},"import"),s(),n("span",{class:"token punctuation"},"{"),s(" ref "),n("span",{class:"token punctuation"},"}"),s(),n("span",{class:"token keyword"},"from"),s(),n("span",{class:"token string"},"'vue'"),s(`

`),n("span",{class:"token keyword"},"export"),s(),n("span",{class:"token keyword"},"default"),s(),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`

    `),n("span",{class:"token keyword"},"const"),s(" icon "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},'"layui-icon-home"'),n("span",{class:"token punctuation"},")"),s(`

    `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token punctuation"},"{"),s(`
      icon
    `),n("span",{class:"token punctuation"},"}"),s(`
  `),n("span",{class:"token punctuation"},"}"),s(`
`),n("span",{class:"token punctuation"},"}"),s(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("script")]),n("span",{class:"token punctuation"},">")]),s(`
`)])],-1)])]),default:l(()=>[o(u,{modelValue:d(t),"onUpdate:modelValue":a[2]||(a[2]=e=>r(t)?t.value=e:t=e),"allow-clear":!0},null,8,["modelValue"])]),_:1}),o(p,{id:"开启分页",title:"开启分页",style:{"margin-top":"21px","margin-bottom":"20px"}}),o(k,null,{description:l(()=>[...a[11]||(a[11]=[n("p",null,"通过 page 属性开启图标列表的分页展示",-1)])]),code:l(()=>[...a[12]||(a[12]=[n("pre",null,[n("code",{"v-pre":""},[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("lay-icon-picker")]),s(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("icon"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},"page"),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("lay-icon-picker")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[s(`
`),n("span",{class:"token keyword"},"import"),s(),n("span",{class:"token punctuation"},"{"),s(" ref "),n("span",{class:"token punctuation"},"}"),s(),n("span",{class:"token keyword"},"from"),s(),n("span",{class:"token string"},"'vue'"),s(`

`),n("span",{class:"token keyword"},"export"),s(),n("span",{class:"token keyword"},"default"),s(),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`

    `),n("span",{class:"token keyword"},"const"),s(" icon "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},'"layui-icon-home"'),n("span",{class:"token punctuation"},")"),s(`

    `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token punctuation"},"{"),s(`
      icon
    `),n("span",{class:"token punctuation"},"}"),s(`
  `),n("span",{class:"token punctuation"},"}"),s(`
`),n("span",{class:"token punctuation"},"}"),s(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("script")]),n("span",{class:"token punctuation"},">")]),s(`
`)])],-1)])]),default:l(()=>[o(u,{modelValue:d(t),"onUpdate:modelValue":a[3]||(a[3]=e=>r(t)?t.value=e:t=e),page:""},null,8,["modelValue"])]),_:1}),o(p,{id:"开启搜索",title:"开启搜索",style:{"margin-top":"21px","margin-bottom":"20px"}}),o(k,null,{description:l(()=>[...a[13]||(a[13]=[n("p",null,"通过 showSearch 开启图标列表的搜索功能",-1)])]),code:l(()=>[...a[14]||(a[14]=[n("pre",null,[n("code",{"v-pre":""},[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("lay-icon-picker")]),s(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("icon"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},"page"),s(),n("span",{class:"token attr-name"},"showSearch"),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("lay-icon-picker")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[s(`
`),n("span",{class:"token keyword"},"import"),s(),n("span",{class:"token punctuation"},"{"),s(" ref "),n("span",{class:"token punctuation"},"}"),s(),n("span",{class:"token keyword"},"from"),s(),n("span",{class:"token string"},"'vue'"),s(`

`),n("span",{class:"token keyword"},"export"),s(),n("span",{class:"token keyword"},"default"),s(),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`

    `),n("span",{class:"token keyword"},"const"),s(" icon "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},'"layui-icon-home"'),n("span",{class:"token punctuation"},")"),s(`

    `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token punctuation"},"{"),s(`
      icon
    `),n("span",{class:"token punctuation"},"}"),s(`
  `),n("span",{class:"token punctuation"},"}"),s(`
`),n("span",{class:"token punctuation"},"}"),s(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("script")]),n("span",{class:"token punctuation"},">")]),s(`
`)])],-1)])]),default:l(()=>[o(u,{modelValue:d(t),"onUpdate:modelValue":a[4]||(a[4]=e=>r(t)?t.value=e:t=e),page:"",showSearch:""},null,8,["modelValue"])]),_:1}),o(p,{id:"icon-picker 属性",title:"icon-picker 属性",style:{"margin-top":"21px","margin-bottom":"20px"}}),o(w,null,{default:l(()=>[...a[15]||(a[15]=[n("table",null,[n("thead",null,[n("tr",null,[n("th",null,"属性"),n("th",null,"说明"),n("th",null,"类型"),n("th",null,"默认值"),n("th",null,"版本")])]),n("tbody",null,[n("tr",null,[n("td",null,"v-model"),n("td",null,"默认值"),n("td",null,"–"),n("td",null,"–"),n("td",null,"–")]),n("tr",null,[n("td",null,"page"),n("td",null,"开启分页"),n("td",null,"–"),n("td",null,"–"),n("td",null,"–")]),n("tr",null,[n("td",null,"size"),n("td",null,"尺寸大小"),n("td",null,[n("code",null,"string")]),n("td",null,[n("code",null,"lg"),s(),n("code",null,"md"),s(),n("code",null,"sm"),s(),n("code",null,"xs")]),n("td",null,[n("code",null,"md")])]),n("tr",null,[n("td",null,"show-search"),n("td",null,"启用搜索"),n("td",null,"–"),n("td",null,"–"),n("td",null,"–")]),n("tr",null,[n("td",null,"disabled"),n("td",null,"禁用"),n("td",null,[n("code",null,"boolean")]),n("td",null,"–"),n("td",null,"–")]),n("tr",null,[n("td",null,"allow-clear"),n("td",null,"允许清空"),n("td",null,[n("code",null,"boolean")]),n("td",null,"–"),n("td",null,"–")]),n("tr",null,[n("td",null,"content-style"),n("td",null,"内容自定义样式"),n("td",null,[n("code",null,"StyleValue")]),n("td",null,"–"),n("td",null,"–")]),n("tr",null,[n("td",null,"content-class"),n("td",null,"内容自定义Class"),n("td",null,[n("code",null,"string"),s(),n("code",null,"Array<string | object>"),s(),n("code",null,"object")]),n("td",null,"–"),n("td",null,"–")]),n("tr",null,[n("td",null,"teleport-props"),n("td",null,[s("继承至 dropdown 组件，下拉面板 "),n("code",null,"传递"),s(" 属性")]),n("td",null,[n("code",null,"object")]),n("td",null,[n("code",null,"{to: 'body', disabled: false}")]),n("td",null,[n("code",null,"2.19.0")])])])],-1)])]),_:1}),n("div",V,[n("div",null,[o(m,{to:"/zh-CN/components/upload",class:"lay-link",style:{display:""}},{default:l(()=>[o(g,{type:"layui-icon-left"}),a[16]||(a[16]=s("文件上传",-1))]),_:1})]),n("div",null,[o(m,{to:"/zh-CN/components/rate",class:"lay-link",style:{display:""}},{default:l(()=>[a[17]||(a[17]=s("评分 ",-1)),o(g,{type:"layui-icon-right"})]),_:1})])])])}}};export{U as default,N as frontmatter};
